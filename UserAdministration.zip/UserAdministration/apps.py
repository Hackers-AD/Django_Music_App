from django.apps import AppConfig


class UseradministrationConfig(AppConfig):
    name = 'UserAdministration'

var count=0;
function SeeOnlineFriends() {
	window.open('/account/activefriend/','_parent');
}
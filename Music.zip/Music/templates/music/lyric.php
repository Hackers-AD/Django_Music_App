{%extends 'music/base.php'%}
{%load static%}
{%block link%}
<link rel="stylesheet" type="text/css" href="{% static 'music/css/lyric.css'%}">
<script type="text/javascript" src="{% static 'music/js/lyric.js'%}"></script>
{%endblock%}
{%block body%}
<body>
	<h2>lyrics Section is Under Deveolopement</h2>
</body>
{%endblock%}
{%extends 'music/base.php'%}
{%load static%}
{%block link%}
<link rel="stylesheet" type="text/css" href="{% static 'music/css/profile.css'%}">
<link rel="stylesheet" type="text/css" href="{% static 'music/css/image_animation.css'%}">
<script type="text/javascript" src="{% static 'music/js/profile.js'%}"></script>
{%endblock%}
{%block body%}
<body>
	<h3>Section under Developement.</h3>
</body>
{%endblock%}
{%extends 'music/base.php'%}
{%load static%}
{%block link%}
<link rel="stylesheet" type="text/css" href="{% static 'music/css/generalsettings.css'%}">
<script type="text/javascript" src="{% static 'music/js/generalsettings.js'%}"></script>
{%endblock%}
{%block body%}
<body>
	<center>Profile Settings</center>
</body>
{%endblock%}
function AccountInfo(argument) {
}
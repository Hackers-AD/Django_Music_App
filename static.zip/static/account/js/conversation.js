function MessageRecord() {
	var conbody=document.getElementById('conbody');
	conbody.contentWindow.location.reload();
}